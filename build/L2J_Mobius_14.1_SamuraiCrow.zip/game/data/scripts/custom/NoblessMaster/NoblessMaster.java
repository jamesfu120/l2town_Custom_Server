/*
 * Copyright (c) 2013 L2jMobius
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
 * IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package custom.NoblessMaster;

import org.l2jmobius.gameserver.config.custom.NoblessMasterConfig;
import org.l2jmobius.gameserver.entity.actor.Npc;
import org.l2jmobius.gameserver.entity.actor.Player;
import org.l2jmobius.gameserver.mechanics.script.QuestSound;
import org.l2jmobius.gameserver.mechanics.script.Script;
import org.l2jmobius.gameserver.network.SystemMessageId;
import org.l2jmobius.gameserver.network.serverpackets.SystemMessage;

/**
 * @author Mobius
 */
public class NoblessMaster extends Script
{
	// Item
	private static final int NOBLESS_TIARA = 7694;
	
	private NoblessMaster()
	{
		addStartNpc(NoblessMasterConfig.NOBLESS_MASTER_NPCID);
		addTalkId(NoblessMasterConfig.NOBLESS_MASTER_NPCID);
		addFirstTalkId(NoblessMasterConfig.NOBLESS_MASTER_NPCID);
	}
	
	@Override
	public String onEvent(String event, Npc npc, Player player)
	{
		if (!NoblessMasterConfig.NOBLESS_MASTER_ENABLED)
		{
			return null;
		}
		
		switch (event)
		{
			case "noblesse":
			{
				if (player.getNobleLevel() > 0)
				{
					return "1003000-3.htm";
				}
				
				if (player.getLevel() < NoblessMasterConfig.NOBLESS_MASTER_LEVEL_REQUIREMENT)
				{
					return "1003000-2.htm";
				}
				
				if (NoblessMasterConfig.NOBLESS_MASTER_ITEM_COUNT > 0)
				{
					if (getQuestItemsCount(player, NoblessMasterConfig.NOBLESS_MASTER_ITEM_ID) < NoblessMasterConfig.NOBLESS_MASTER_ITEM_COUNT)
					{
						final SystemMessage msg = new SystemMessage(SystemMessageId.YOU_NEED_S1_X_S2);
						msg.addItemName(NoblessMasterConfig.NOBLESS_MASTER_ITEM_ID);
						msg.addLong(NoblessMasterConfig.NOBLESS_MASTER_ITEM_COUNT);
						player.sendPacket(msg);
						return "1003000-4.htm";
					}
					
					takeItems(player, NoblessMasterConfig.NOBLESS_MASTER_ITEM_ID, NoblessMasterConfig.NOBLESS_MASTER_ITEM_COUNT);
				}
				
				if (NoblessMasterConfig.NOBLESS_MASTER_REWARD_TIARA)
				{
					giveItems(player, NOBLESS_TIARA, 1);
				}
				
				player.setNobleLevel(NoblessMasterConfig.NOBLESS_MASTER_LEVEL_REWARDED);
				player.sendPacket(QuestSound.ITEMSOUND_QUEST_FINISH.getPacket());
				return "1003000-1.htm";
			}
		}
		
		return null;
	}
	
	@Override
	public String onFirstTalk(Npc npc, Player player)
	{
		return "1003000.htm";
	}
	
	public static void main(String[] args)
	{
		new NoblessMaster();
	}
}
