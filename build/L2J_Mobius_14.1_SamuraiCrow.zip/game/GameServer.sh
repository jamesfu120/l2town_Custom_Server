#! /bin/sh

./GameServerTask.sh &